DROP DATABASE IF EXISTS CONSTRUCTORA;
CREATE DATABASE IF NOT EXISTS CONSTRUCTORA;
USE CONSTRUCTORA;

CREATE TABLE ROLES
(
    ID          INT AUTO_INCREMENT PRIMARY KEY,
    NOMBRE      VARCHAR(50),
    DESCRIPCION TEXT
);

CREATE TABLE PERSONAL
(
    ID       INT AUTO_INCREMENT PRIMARY KEY,
    NOMBRE   VARCHAR(50),
    APELLIDO VARCHAR(50),
    ID_ROL   INT,
    CONSTRAINT `PERSONAL->ROL` FOREIGN KEY (ID_ROL) REFERENCES ROLES (ID)
);

CREATE TABLE ESTADOS_CAMBIOS
(
    ID          INT AUTO_INCREMENT PRIMARY KEY,
    NOMBRE      VARCHAR(50),
    DESCRIPCION TEXT
);

CREATE TABLE TAREAS
(
    ID          INT AUTO_INCREMENT PRIMARY KEY,
    NOMBRE      VARCHAR(50),
    DESCRIPCION TEXT
);

CREATE TABLE ESTADOS_CONSTRUCCIONES
(
    ID          INT AUTO_INCREMENT PRIMARY KEY,
    NOMBRE      VARCHAR(50),
    DESCRIPCION TEXT
);

CREATE TABLE DISTRIBUCIONES
(
    ID          INT AUTO_INCREMENT PRIMARY KEY,
    NOMBRE      VARCHAR(50),
    DESCRIPCION TEXT
);

CREATE TABLE MATERIALES
(
    ID          INT AUTO_INCREMENT PRIMARY KEY,
    NOMBRE      VARCHAR(50),
    DESCRIPCION TEXT,
    STOCK       INT
);

CREATE TABLE VIVIENDAS
(
    ID                     INT AUTO_INCREMENT PRIMARY KEY,
    ID_ESTADO_CONSTRUCCION INT,
    ID_DISTRIBUCION        INT,
    FECHA_INICIO           DATE,
    FECHA_FIN              DATE,
    COSTO                  BIGINT,
    CONSTRAINT `VIVIENDA->ESTADO_CONSTRUCCION` FOREIGN KEY (ID_ESTADO_CONSTRUCCION) REFERENCES ESTADOS_CONSTRUCCIONES (ID),
    CONSTRAINT `VIVIENDA->DISTRIBUCION` FOREIGN KEY (ID_DISTRIBUCION) REFERENCES DISTRIBUCIONES (ID)
);


CREATE TABLE CRONOGRAMA
(
    ID          INT AUTO_INCREMENT PRIMARY KEY,
    ID_TAREA    INT,
    ID_VIVIENDA INT,
    CONSTRAINT `CRONOGRAMA->TAREA` FOREIGN KEY (ID_TAREA) REFERENCES TAREAS (ID),
    CONSTRAINT `CRONOGRAMA->VIVENDA` FOREIGN KEY (ID_VIVIENDA) REFERENCES VIVIENDAS (ID)
);

CREATE TABLE PERSONAL_CRONOGRAMA
(
    ID            INT AUTO_INCREMENT PRIMARY KEY,
    ID_CRONOGRAMA INT,
    ID_PERSONAL   INT,
    CONSTRAINT `PERSONAL_CRONOGRAMA->CRONOGRAMA` FOREIGN KEY (ID_CRONOGRAMA) REFERENCES CRONOGRAMA (ID),
    CONSTRAINT `PERSONAL_CRONOGRAMA->PERSONAL` FOREIGN KEY (ID_PERSONAL) REFERENCES PERSONAL (ID)
);

CREATE TABLE VIVIENDAS_MATERIALES
(
    ID          INT AUTO_INCREMENT PRIMARY KEY,
    ID_VIVENDA  INT,
    ID_MATERIAL INT,
    CANTIDAD    INT,
    CONSTRAINT `VIVENDAS_MATERIALES->VIVENDA` FOREIGN KEY (ID_VIVENDA) REFERENCES VIVIENDAS (ID),
    CONSTRAINT `VIVENDAS_MATERIALES->MATERIAL` FOREIGN KEY (ID_MATERIAL) REFERENCES MATERIALES (ID)
);


CREATE TABLE SOLICITUD_CAMBIOS
(
    ID           INT AUTO_INCREMENT PRIMARY KEY,
    NOMBRE       VARCHAR(50),
    DEDSCRIPCION TEXT,
    ID_ESTADO    INT,
    ID_VIVIENDA  INT,
    CONSTRAINT `SOLICITUD_CAMBIOS->ESTADO` FOREIGN KEY (ID_ESTADO) REFERENCES ESTADOS_CAMBIOS (ID),
    CONSTRAINT `SOLICITUD_CAMBIOS->VIVENDA` FOREIGN KEY (ID_VIVIENDA) REFERENCES VIVIENDAS (ID)
);

CREATE TABLE CAMBIO
(
    ID           INT AUTO_INCREMENT PRIMARY KEY,
    NOMBRE       VARCHAR(50),
    DESCRIPCION  TEXT,
    ID_SOLICITUD INT,
    CONSTRAINT `CAMBIO->SOLICITUD_CAMBIO` FOREIGN KEY (ID_SOLICITUD) REFERENCES SOLICITUD_CAMBIOS (ID)
);

CREATE TABLE REVISIONES
(
    ID          INT AUTO_INCREMENT PRIMARY KEY,
    DESCRIPCION TEXT,
    ID_VIVENDA  INT,
    CONSTRAINT `REVISION->VIVIENDA` FOREIGN KEY (ID_VIVENDA) REFERENCES VIVIENDAS (ID)
);
-- inserts
INSERT INTO ROLES (NOMBRE, DESCRIPCION)
VALUES ('Gerente', 'Encargado de la gestión y administración de la constructora'),
       ('Supervisor', 'Encargado de la supervisión de las obras y del personal asignado'),
       ('Maestro de obra', 'Encargado de la ejecución de las obras'),
       ('Albañil', 'Encargado de la construcción de mampostería y estructuras'),
       ('Carpintero', 'Encargado de la construcción de estructuras y acabados de madera');

INSERT INTO PERSONAL (NOMBRE, APELLIDO, ID_ROL)
VALUES ('Juan', 'Pérez', 1),
       ('Pedro', 'García', 2),
       ('Luis', 'Martínez', 2),
       ('José', 'González', 3),
       ('Mario', 'Hernández', 4);

INSERT INTO ESTADOS_CAMBIOS (NOMBRE, DESCRIPCION)
VALUES ('Pendiente', 'Solicitud de cambio pendiente de revisión'),
       ('Aprobado', 'Solicitud de cambio aprobada'),
       ('Rechazado', 'Solicitud de cambio rechazada');

INSERT INTO TAREAS (NOMBRE, DESCRIPCION)
VALUES ('Excavación de cimientos', 'Excavación y preparación de terreno para los cimientos'),
       ('Levantamiento de muros', 'Construcción de mampostería para levantar los muros'),
       ('Instalación eléctrica', 'Instalación de cableado y conexiones eléctricas'),
       ('Instalación de plomería', 'Instalación de tuberías y conexiones de plomería'),
       ('Instalación de pisos y acabados', 'Instalación de pisos, acabados y pintura');

INSERT INTO ESTADOS_CONSTRUCCIONES (NOMBRE, DESCRIPCION)
VALUES ('EN PROGRESO', 'Proyecto en fase de planificación'),
       ('En construcción', 'Proyecto en fase de construcción'),
       ('Finalizado', 'Proyecto finalizado y entregado al cliente');

INSERT INTO DISTRIBUCIONES (NOMBRE, DESCRIPCION)
VALUES ('1 dormitorio', 'Vivienda con un dormitorio'),
       ('2 dormitorios', 'Vivienda con dos dormitorios'),
       ('3 dormitorios', 'Vivienda con tres dormitorios'),
       ('4 dormitorios', 'Vivienda con cuatro dormitorios');

INSERT INTO MATERIALES (NOMBRE, DESCRIPCION, STOCK)
VALUES ('Cemento', 'Material utilizado para la construcción de cimientos y estructuras', 500),
       ('Ladrillos', 'Material utilizado para la construcción de mampostería y muros', 10000),
       ('Madera', 'Material utilizado para la construcción de estructuras y acabados', 2000),
       ('Tuberías de PVC', 'Material utilizado para la instalación de plomería', 500),
       ('Cables eléctricos', 'Material utilizado para la instalación eléctrica', 1000);

INSERT INTO VIVIENDAS (ID_ESTADO_CONSTRUCCION, ID_DISTRIBUCION, FECHA_INICIO, FECHA_FIN, COSTO)
VALUES (1, 1, '2022-03-20', NULL, 10000000),
       (1, 2, '2022-03-21', NULL, 20000000),
       (2, 3, '2022-03-22', '2022-05-22', 30000000),
       (2, 4, '2022-03-23', '2022-05-22', 40000000),
       (3, 1, '2022-03-24', '2022-07-22', 50000000);

INSERT INTO CRONOGRAMA (ID_TAREA, ID_VIVIENDA)
VALUES (1, 1),
       (1, 2),
       (2, 3),
       (2, 4),
       (3, 1);

INSERT INTO PERSONAL_CRONOGRAMA (ID_CRONOGRAMA, ID_PERSONAL)
VALUES (1, 4),
       (2, 5),
       (3, 3),
       (4, 4),
       (5, 2);

INSERT INTO VIVIENDAS_MATERIALES (ID_VIVENDA, ID_MATERIAL, CANTIDAD)
VALUES (1, 1, 9),
       (1, 2, 9),
       (2, 1, 5),
       (2, 2, 6),
       (3, 3, 3);

INSERT INTO SOLICITUD_CAMBIOS (NOMBRE, DEDSCRIPCION, ID_ESTADO, ID_VIVIENDA)
VALUES ('Cambio de distribución', 'Solicito cambiar la distribución de la vivienda.', 1, 1),
       ('Modificación de planos', 'Solicito hacer modificaciones en los planos de la vivienda.', 1, 2),
       ('Cambio de acabados', 'Solicito cambiar los acabados de la vivienda.', 1, 3),
       ('Cambio de distribución', 'Solicito cambiar la distribución de la vivienda.', 2, 4),
       ('Añadir una habitación', 'Solicito añadir una habitación a la vivienda.', 2, 1);

INSERT INTO CAMBIO (NOMBRE, DESCRIPCION, ID_SOLICITUD)
VALUES ('Modificación de distribución', 'Se ha modificado la distribución de la vivienda.', 1),
       ('Modificación de planos', 'Se han modificado los planos de la vivienda.', 2),
       ('Modificación de acabados', 'Se han modificado los acabados de la vivienda.', 3),
       ('Modificación de distribución', 'Se ha modificado la distribución de la vivienda.', 4),
       ('Añadir habitación', 'Se ha añadido una habitación a la vivienda.', 5);

INSERT INTO REVISIONES (DESCRIPCION, ID_VIVENDA)
VALUES ('APROBADA', 1),
       ('APROBADA', 1),
       ('GAS NATURAL CONECTADO', 1),
       ('HUMEDAD EN EL TECHO DEL DORMITORIO', 1),
       ('AGUA DE RED', 1),
       ('FIBRA OPTICA INSTALADA', 1),
       ('APROBADA', 2),
       ('APROBADA', 3),
       ('APROBADA', 4),
       ('APROBADA', 5);


SELECT *
FROM VIVIENDAS
         INNER JOIN ESTADOS_CONSTRUCCIONES EC on VIVIENDAS.ID_ESTADO_CONSTRUCCION = EC.ID
WHERE FECHA_INICIO < DATE_SUB(NOW(), INTERVAL 139 DAY)
  AND EC.NOMBRE = 'EN PROGRESO';

SELECT COUNT(*),
       (SELECT MAX(COSTO) FROM VIVIENDAS) AS VIVIENDA_MAYOR_COSTO,
       (SELECT MIN(COSTO) FROM VIVIENDAS) AS VIVIENDA_MENOR_COSTO
FROM VIVIENDAS
         INNER JOIN ESTADOS_CONSTRUCCIONES EC on VIVIENDAS.ID_ESTADO_CONSTRUCCION = EC.ID
WHERE FECHA_FIN >= MONTH(NOW() - 6);

SELECT V.ID AS ID_VIVIENDA, M.NOMBRE as MATERIAL, CANTIDAD AS CANTIDAD_MATERIAL, count(R.ID) AS CANTIDAD_VISITAS
FROM VIVIENDAS_MATERIALES
         INNER JOIN MATERIALES M on VIVIENDAS_MATERIALES.ID_MATERIAL = M.ID
         INNER JOIN VIVIENDAS V on VIVIENDAS_MATERIALES.ID_VIVENDA = V.ID
         INNER JOIN REVISIONES R ON V.ID = R.ID_VIVENDA
WHERE M.NOMBRE = 'Cemento'
  AND VIVIENDAS_MATERIALES.CANTIDAD = 9
GROUP BY V.ID, M.NOMBRE, CANTIDAD
HAVING count(R.ID) > 5;

SELECT P.ID, P.NOMBRE, P.APELLIDO, SUM(V.COSTO * 0.01) AS GANANCIAS, MAX(V.COSTO) AS PROYECTO_MAS_COSTOSO
FROM PERSONAL P
         JOIN PERSONAL_CRONOGRAMA PC ON P.ID = PC.ID_PERSONAL
         JOIN CRONOGRAMA C ON PC.ID_CRONOGRAMA = C.ID
         JOIN VIVIENDAS V ON C.ID_VIVIENDA = V.ID
GROUP BY P.ID, P.NOMBRE, P.APELLIDO;
